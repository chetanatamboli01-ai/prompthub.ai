/*
  Frontend helper for PromptHub.
  Include this file in your HTML:
    <script src="/deepseek-client.js" defer></script>

  Example usage from a button handler:
    const result = await PromptHubAI.run({
      prompt: document.querySelector("#promptInput").value,
      task: "improve"
    });
    document.querySelector("#aiOutput").textContent = result;

  Supported tasks: "improve", "generate", "explain", "rewrite".
*/
window.PromptHubAI = {
  async run({ prompt, task = "improve" } = {}) {
    const response = await fetch("/api/ai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, task })
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "AI request failed.");
    return data.result;
  }
};
