# PromptHub + DeepSeek (secure starter)

This adds a small Node.js backend so PromptHub can use DeepSeek without exposing the API key in browser code.

## Important security note
A DeepSeek API key was posted in chat previously. Treat it as compromised: revoke it and create a new one. Do not reuse the posted key. Never put the new key in HTML, frontend JavaScript, or a public repository.

## Setup
1. Install Node.js 20 or newer.
2. Extract this folder and open a terminal in it.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your NEW key in `.env`:
   `DEEPSEEK_API_KEY=your_new_key`
6. Run `npm start`.
7. Open `http://localhost:3000/api/health`. It should show `configured: true`.

## Connect to the existing PromptHub HTML
Copy your existing PromptHub HTML into this folder as `public/index.html` (or move its contents there). Add this line before `</body>`:

```html
<script src="/deepseek-client.js" defer></script>
```

Add an output area where you want AI results to appear:

```html
<textarea id="aiOutput" rows="8" placeholder="DeepSeek result will appear here"></textarea>
```

Then wire your existing AI button to your prompt input. Replace `#promptInput` with the actual selector/ID used by your page:

```html
<script>
async function improvePromptWithDeepSeek() {
  const input = document.querySelector("#promptInput");
  const output = document.querySelector("#aiOutput");
  if (!input || !output) {
    alert("Connect the code to your prompt input and output elements first.");
    return;
  }
  output.value = "Working...";
  try {
    output.value = await PromptHubAI.run({
      prompt: input.value,
      task: "improve"
    });
  } catch (error) {
    output.value = "";
    alert(error.message);
  }
}
</script>
```

Set your AI button to call `improvePromptWithDeepSeek()`:
`<button type="button" onclick="improvePromptWithDeepSeek()">Improve with DeepSeek</button>`

To generate a prompt instead, use `task: "generate"`. Other supported tasks are `"explain"` and `"rewrite"`.

## Deploying
Deploy the Node server to a hosting provider that supports Node.js, and set `DEEPSEEK_API_KEY` as a private environment variable in that provider's dashboard. Do not expose `.env`. If your current host only serves static HTML, it cannot run this backend by itself.

## Notes
- This starter is not yet integrated into your exact PromptHub page because the original HTML source wasn't available in the current file workspace. Copy your existing HTML into `public/index.html` and connect the actual input/button selectors as described above.
- The endpoint has a basic per-IP rate limit. For a public production site, also add user authentication/quotas and monitoring.
